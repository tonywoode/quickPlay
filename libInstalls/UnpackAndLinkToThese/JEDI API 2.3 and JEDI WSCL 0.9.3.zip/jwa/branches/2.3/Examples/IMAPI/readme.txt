This example contains a unit that implements the Image Mastering API (IMAPI) with objects.
It also includes a demonstration.

Date
	20. July 2009

Article:
	http://blog.delphi-jedi.net/2009/07/18/im-burning-baby

Units

uDiscBurner.pas
	This is the IMAPI wrapper unit. It was written in Delphi 2006 and 2009.

DiscBurner.dpr
	This is the demonstration project. It was writtein in Delphi 2009.
uFormMain
	The main formular of the project.
	
	
Please refer to the corresponding file for further information.
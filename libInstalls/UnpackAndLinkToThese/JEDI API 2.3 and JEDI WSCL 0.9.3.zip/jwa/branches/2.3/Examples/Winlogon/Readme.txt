to compile this example you need to download the following:

http://sourceforge.net/projects/graphics32
http://www.thany.org/download/14/pngcomponentssetup.zip

stOrM!

